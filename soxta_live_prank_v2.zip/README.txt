SOXTA LIVE PRANK DEMO — v2

OCHISH:
1. ZIP faylni oching.
2. index.html faylini brauzerda oching yoki GitHub repository'ning ROOT qismiga yuklang.
3. GitHub Pages: Settings -> Pages -> Deploy from a branch -> main -> /(root) -> Save.
4. Sayt ochilmasa, Actions bo‘limida Pages deploy holatini tekshiring.

MUHIM:
- Bu haqiqiy LIVE emas; chat va tomoshabinlar faqat simulyatsiya.
- Hech kimning kamerasiga kira olmaydi.
- Kamera tugmasi faqat sizning qurilmangiz kamerasini, siz brauzer ruxsati berganingizdan keyin ko‘rsatadi.
- Kamera HTTPS yoki localhost talab qiladi; GitHub Pages HTTPS bilan ishlaydi.
- Bu versiya bitta index.html faylida: CSS va JavaScript ichida, shuning uchun alohida fayl yo‘qolishi muammosi bo‘lmaydi.
